export default function Home() {
  const bots = [
    { name: "Boom 1000 Bot", description: "A free volatility bot for Boom 1000", link: "#" },
    { name: "Crash 500 Bot", description: "Crash 500 optimized scalping bot", link: "#" },
    { name: "V75 Sniper", description: "Powerful V75 strategy bot", link: "#" }
  ];

  return (
    <main className="p-6 font-sans">
      <h1 className="text-3xl font-bold mb-4">CK Deriv Bots</h1>
      <p className="mb-6">Download free & premium bots. Trade better on Deriv. <a href="https://deriv.com/?your_affiliate_id" className="text-blue-600 underline">Sign up on Deriv</a></p>
      <div className="grid gap-4">
        {bots.map((bot, index) => (
          <div key={index} className="border p-4 rounded-lg shadow">
            <h2 className="text-xl font-semibold">{bot.name}</h2>
            <p className="text-gray-600">{bot.description}</p>
            <a href={bot.link} className="inline-block mt-2 px-4 py-2 bg-blue-500 text-white rounded">Download</a>
          </div>
        ))}
      </div>
    </main>
  );
}